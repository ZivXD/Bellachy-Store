import { useEffect } from 'react';
import AnnouncementBar from './components/AnnouncementBar.jsx';
import Header from './components/Header.jsx';
import Hero from './components/Hero.jsx';
import TrustBadges from './components/TrustBadges.jsx';
import FeaturedProducts from './components/FeaturedProducts.jsx';
import EducationSection from './components/EducationSection.jsx';
import ReviewsSection from './components/ReviewsSection.jsx';
import FAQSection from './components/FAQSection.jsx';
import Footer from './components/Footer.jsx';
import CartDrawer from './components/CartDrawer.jsx';
import StickyBottomBar from './components/StickyBottomBar.jsx';
import { useCart } from './context/CartContext.jsx';

function ScrollController() {
  const { setShowStickyBar } = useCart();
  useEffect(() => {
    const onScroll = () => {
      const heroEl = document.getElementById('badges');
      const threshold = heroEl ? heroEl.getBoundingClientRect().top + window.scrollY : 500;
      setShowStickyBar(window.scrollY > threshold - 80);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
    };
  }, [setShowStickyBar]);
  return null;
}

function App() {
  return (
    <div className="min-h-screen bg-luxury-black text-luxury-white overflow-x-hidden">
      <ScrollController />
      <AnnouncementBar />
      <Header />
      <main>
        <Hero />
        <TrustBadges />
        <FeaturedProducts />
        <EducationSection />
        <ReviewsSection />
        <FAQSection />
      </main>
      <Footer />
      <CartDrawer />
      <StickyBottomBar />
    </div>
  );
}

export default App;
