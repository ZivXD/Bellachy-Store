import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, ChevronLeft, ChevronRight, Quote, CheckCircle, User } from 'lucide-react';
import { reviews, reviewStats } from '../data/reviews.js';

export default function ReviewsSection() {
  const [filter, setFilter] = useState(0);
  const scrollerRef = useRef(null);
  const [autoScroll, setAutoScroll] = useState(true);

  const filtered = filter === 0 ? reviews : reviews.filter((r) => r.rating === filter);

  useEffect(() => {
    if (!autoScroll || !scrollerRef.current) return;
    const el = scrollerRef.current;
    const i = setInterval(() => {
      if (!el) return;
      const max = el.scrollWidth - el.clientWidth;
      if (el.scrollLeft + el.clientWidth >= max - 2) {
        el.scrollTo({ left: 0, behavior: 'smooth' });
      } else {
        el.scrollBy({ left: 340, behavior: 'smooth' });
      }
    }, 4200);
    return () => clearInterval(i);
  }, [autoScroll, filtered]);

  const pct = (n) => Math.round((reviewStats.breakdown[n] / reviewStats.total) * 100);

  return (
    <section id="reviews" className="relative py-20 sm:py-24 overflow-hidden border-t border-luxury-gold/10 bg-luxury-charcoal/25">
      <div className="absolute top-0 left-1/4 w-[500px] h-[400px] bg-luxury-gold/5 blur-[130px] rounded-full pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          className="text-center max-w-3xl mx-auto mb-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/25 text-xs font-bold text-amber-300 tracking-wider mb-5">
            <Star size={14} className="fill-current" /> 1,247 ביקורות מאומתות • דירוג 4.9/5
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black mb-4 leading-tight">
            <span className="text-luxury-white">המילה ש </span>
            <span className="text-gold-gradient">הלקוחות שלנו</span>
            <span className="text-luxury-white"> אומרים</span>
          </h2>
          <p className="text-luxury-text/75 text-base sm:text-lg leading-relaxed">
            אין דבר שמשכנע יותר מאשר הרגשת אמיתית של לקוחות שכבר קנו, בחנו ואוהבות את BÉLLACHY.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-[340px_1fr] gap-8 mb-8">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            className="rounded-2xl p-5 sm:p-6 bg-luxury-charcoal/60 border border-luxury-gold/20"
          >
            <div className="text-center mb-5 pb-5 border-b border-luxury-gold/10">
              <div className="text-5xl sm:text-6xl font-black text-gold-gradient mb-2">
                {reviewStats.average.toFixed(1)}
              </div>
              <div className="flex items-center justify-center gap-1 mb-1.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} size={18} className="fill-luxury-gold-light text-luxury-gold-light" />
                ))}
              </div>
              <div className="text-sm text-luxury-muted">בסך הכל {reviewStats.total.toLocaleString('he-IL')} ביקורות מאומתות</div>
            </div>

            <div className="space-y-3">
              {[5, 4, 3, 2, 1].map((n) => (
                <button
                  key={n}
                  onClick={() => setFilter(filter === n ? 0 : n)}
                  className={`w-full grid grid-cols-[28px_1fr_38px] items-center gap-3 text-right rounded-xl p-2 transition-all ${
                    filter === n
                      ? 'bg-luxury-gold/15 ring-1 ring-luxury-gold/40'
                      : 'hover:bg-luxury-black/40'
                  }`}
                >
                  <div className="flex items-center gap-1 text-luxury-gold-light">
                    <Star size={14} className="fill-current" />
                    <span className="text-xs font-bold">{n}</span>
                  </div>
                  <div className="h-2 rounded-full bg-luxury-black/70 overflow-hidden">
                    <div
                      className="h-full bg-gold-gradient rounded-full transition-all duration-700"
                      style={{ width: `${pct(n)}%` }}
                    />
                  </div>
                  <div className="text-left text-xs font-bold text-luxury-text/70">{pct(n)}%</div>
                </button>
              ))}
            </div>
            {filter !== 0 && (
              <button
                onClick={() => setFilter(0)}
                className="w-full mt-5 py-2.5 rounded-xl text-xs font-bold border border-luxury-gold/30 text-luxury-gold-light hover:bg-luxury-gold/10 transition"
              >
                איפוס סינון – הצג את כל הביקורות
              </button>
            )}
          </motion.div>

          <div className="relative">
            <div className="absolute top-1/2 -translate-y-1/2 right-0 z-20 hidden sm:block">
              <button
                onClick={() => scrollerRef.current?.scrollBy({ left: -360, behavior: 'smooth' })}
                onMouseEnter={() => setAutoScroll(false)}
                className="w-11 h-11 rounded-full glass-dark border border-luxury-gold/20 flex items-center justify-center text-luxury-gold-light hover:bg-luxury-gold/15 transition mr-2"
                aria-label="ביקורות קודמות"
              >
                <ChevronRight size={20} />
              </button>
            </div>
            <div className="absolute top-1/2 -translate-y-1/2 left-0 z-20 hidden sm:block">
              <button
                onClick={() => scrollerRef.current?.scrollBy({ left: 360, behavior: 'smooth' })}
                onMouseEnter={() => setAutoScroll(false)}
                className="w-11 h-11 rounded-full glass-dark border border-luxury-gold/20 flex items-center justify-center text-luxury-gold-light hover:bg-luxury-gold/15 transition ml-2"
                aria-label="ביקורות הבאות"
              >
                <ChevronLeft size={20} />
              </button>
            </div>

            <div
              ref={scrollerRef}
              onMouseEnter={() => setAutoScroll(false)}
              onMouseLeave={() => setAutoScroll(true)}
              className="flex gap-5 overflow-x-auto scrollbar-hide snap-x snap-mandatory pb-3 -mx-1 px-1 scroll-smooth"
            >
              <AnimatePresence mode="popLayout">
                {filtered.map((r) => (
                  <motion.div
                    layout
                    key={r.id}
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -12 }}
                    transition={{ duration: 0.3 }}
                    className="snap-start shrink-0 w-[88%] sm:w-[420px] rounded-2xl p-5 sm:p-6 bg-luxury-charcoal/55 border border-luxury-gold/15 hover:border-luxury-gold/35 transition"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <Quote size={28} strokeWidth={1.5} className="text-luxury-gold/40" />
                      <div className="flex items-center gap-0.5">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            size={15}
                            className={i < r.rating ? 'fill-luxury-gold-light text-luxury-gold-light' : 'text-luxury-muted/40'}
                          />
                        ))}
                      </div>
                    </div>

                    <h4 className="font-bold text-luxury-white mb-2 leading-snug">{r.title}</h4>
                    <p className="text-sm text-luxury-text/80 leading-relaxed mb-5">
                      {r.content}
                    </p>

                    <div className="flex items-center justify-between pt-4 border-t border-luxury-gold/10">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-gold-gradient text-luxury-black flex items-center justify-center font-black text-sm shadow-gold-glow">
                          {r.avatar.split('').map((c) => c).join('')}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-sm text-luxury-white">{r.name}</span>
                            <CheckCircle size={13} className="text-emerald-400" />
                          </div>
                          <div className="text-[11px] text-luxury-muted">
                            {r.location} • {r.date}
                          </div>
                        </div>
                      </div>
                      {r.verified && (
                        <div className="flex items-center gap-1 px-2 py-1 rounded-md bg-emerald-500/10 border border-emerald-500/20 text-[10px] font-black text-emerald-300">
                          <User size={11} /> קונה מאומת
                        </div>
                      )}
                    </div>
                    <div className="mt-3 text-[11px] text-luxury-muted inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-luxury-black/40 border border-luxury-gold/10">
                      ✦ {r.product}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
