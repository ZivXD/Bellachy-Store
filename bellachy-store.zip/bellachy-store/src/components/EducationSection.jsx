import { motion } from 'framer-motion';
import { Sparkles, Shield, Check, X, Gem, Droplets, Zap, Award } from 'lucide-react';

const comparisonRows = [
  { label: 'ניצוץ (שבירת אור)', moissanite: '2.65 – גבוה יותר מיהלום', diamond: '2.42', winner: 'm' },
  { label: 'דרגת צבע', moissanite: 'D-Color (צבע הלבן העליון)', diamond: 'תלוי במחיר – D-G עד ₪50,000', winner: 'm' },
  { label: 'דרגת ניקיון', moissanite: 'VVS1 (ניקוי עליון) בסטנדרט', diamond: 'תלוי במחיר – VVS1 יקר במיוחד', winner: 'm' },
  { label: 'עמידות לשריטות', moissanite: '9.25 בסולם Mohs (קרוב ליהלום)', diamond: '10 בסולם Mohs (הקשה ביותר)', winner: 'd' },
  { label: 'התנהגות במודד יהלומים', moissanite: 'עובר – מדורג כיהלום', diamond: 'עובר', winner: '=' },
  { label: 'מחיר לדוגמה 1 קראט', moissanite: '~ ₪500 – ₪900', diamond: '~ ₪25,000 – ₪80,000', winner: 'm' },
  { label: 'סביבתי / אתי', moissanite: 'יוצרים מעבדתית ללא כרייה', diamond: 'לרוב מכרות עם השפעה סביבתית', winner: 'm' },
];

export default function EducationSection() {
  return (
    <>
      <section id="compare" className="relative py-20 sm:py-24 overflow-hidden border-t border-luxury-gold/10">
        <div className="absolute top-20 left-0 w-[450px] h-[450px] bg-blue-500/5 blur-[130px] rounded-full pointer-events-none" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            className="text-center max-w-3xl mx-auto mb-14"
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-sky-500/10 border border-sky-500/25 text-xs font-bold text-sky-300 tracking-wider mb-5">
              <Gem size={14} /> איכות ללא פשרות • מואסניט מול יהלום
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black mb-4 leading-tight">
              <span className="text-luxury-white">למה </span>
              <span className="text-gold-gradient">מואסניט</span>
              <span className="text-luxury-white"> זה הבחירה החכמה יותר?</span>
            </h2>
            <p className="text-luxury-text/75 text-base sm:text-lg leading-relaxed">
              השוואה אובייקטיבית בין מואסניט באיכות העליונה שלנו לבין יהלום טבעי באיכות
              זהה – התכונות מדברות בעד עצמן.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.55 }}
            className="overflow-hidden rounded-3xl border border-luxury-gold/20 bg-luxury-charcoal/40 backdrop-blur"
          >
            <div className="grid grid-cols-4 bg-luxury-gold/10 border-b border-luxury-gold/20 text-xs sm:text-sm font-bold">
              <div className="col-span-2 p-4 sm:p-5 text-luxury-muted tracking-wider uppercase">מאפיין</div>
              <div className="p-4 sm:p-5 text-luxury-gold-light text-center border-r border-luxury-gold/15">
                ✦ מואסניט BÉLLACHY
              </div>
              <div className="p-4 sm:p-5 text-luxury-white/80 text-center">יהלום טבעי</div>
            </div>

            {comparisonRows.map((row, i) => (
              <div
                key={row.label}
                className={`grid grid-cols-4 border-b last:border-b-0 border-luxury-gold/10 ${
                  i % 2 === 0 ? 'bg-luxury-black/40' : 'bg-transparent'
                }`}
              >
                <div className="col-span-2 p-4 sm:p-5 text-sm sm:text-base text-luxury-text/90 flex items-center">
                  {row.label}
                </div>
                <div className="p-4 sm:p-5 text-sm sm:text-base text-luxury-gold-light text-center border-r border-luxury-gold/10 flex items-center justify-center">
                  <span className="flex items-center gap-1.5 justify-center">
                    {row.winner === 'm' && (
                      <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-luxury-gold/20 text-luxury-gold-light">
                        <Check size={12} strokeWidth={3} />
                      </span>
                    )}
                    {row.moissanite}
                  </span>
                </div>
                <div className="p-4 sm:p-5 text-sm sm:text-base text-luxury-text/75 text-center flex items-center justify-center">
                  <span className="flex items-center gap-1.5 justify-center">
                    {row.winner === 'd' && (
                      <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-luxury-white/10 text-luxury-white">
                        <Check size={12} strokeWidth={3} />
                      </span>
                    )}
                    {row.winner === '=' && (
                      <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-luxury-white/5 text-luxury-muted">
                        <X size={12} strokeWidth={3} />
                      </span>
                    )}
                    {row.diamond}
                  </span>
                </div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      <section id="quality" className="relative py-20 sm:py-24 overflow-hidden">
        <div className="absolute -bottom-20 right-10 w-[500px] h-[500px] bg-amber-500/5 blur-[140px] rounded-full pointer-events-none" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-start">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.55 }}
            >
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/25 text-xs font-bold text-cyan-300 tracking-wider mb-5">
                <Droplets size={14} /> טכנולוגיית E-Coating לדור חדש
              </div>
              <h2 className="text-3xl sm:text-4xl font-black mb-5 leading-tight">
                <span className="text-luxury-white">עמיד למים. עמיד לזמן. </span>
                <span className="text-gold-gradient">עמיד לבחינת העולם.</span>
              </h2>
              <p className="text-luxury-text/80 leading-relaxed mb-6 text-base sm:text-lg">
                כל תכשיט BÉLLACHY עובר תהליך E-Coating אלקטרופורטי מתקדם – שכבה
                אלקטרוסטטית שקופה ונאטמת לחלוטין על גבי הכסף 925 וציפוי הרודיום/זהב.
              </p>

              <ul className="space-y-3.5 mb-7">
                {[
                  { t: 'מונע השחרה וחמצון של הכסף באביבות מלוחות', icon: Shield },
                  { t: 'עמיד למים וזיעה בשימוש יומיומי מלא – מקלחות, ים, אימונים', icon: Droplets },
                  { t: 'הפחתת שחיקה של הציפוי בפי 5 לעומת תכשיטים רגילים', icon: Zap },
                  { t: 'היפואלרגני – ללא גירוי של העור אצל רוב האוכלוסייה', icon: Award },
                ].map(({ t, icon: I }) => (
                  <li key={t} className="flex items-start gap-3 p-3 rounded-xl bg-luxury-charcoal/40 border border-luxury-gold/10">
                    <div className="w-9 h-9 rounded-lg bg-luxury-gold/10 border border-luxury-gold/20 flex items-center justify-center shrink-0">
                      <I size={18} className="text-luxury-gold-light" />
                    </div>
                    <span className="text-luxury-text/90 pt-1 leading-relaxed">{t}</span>
                  </li>
                ))}
              </ul>

              <div className="rounded-2xl p-5 sm:p-6 bg-gradient-to-br from-cyan-500/10 via-luxury-charcoal/80 to-luxury-gold/10 border border-cyan-500/20">
                <div className="flex items-start gap-2 mb-2">
                  <Sparkles size={18} className="text-cyan-300 mt-0.5 shrink-0" />
                  <h4 className="font-bold text-luxury-white">הוראות טיפול לשמירה על ברק מקסימלי</h4>
                </div>
                <p className="text-sm text-luxury-text/80 leading-relaxed">
                  כדי לשמור על שכבת ההגנה לאורך שנים, מומלץ להימנע ממגע ישיר עם
                  <strong className="text-luxury-white"> כלור בבריכות</strong>,
                  <strong className="text-luxury-white"> חומרי ניקוי כימיים</strong> ו
                  <strong className="text-luxury-white"> בשמים בריכוז גבוה</strong>.
                  לניקוי יומיומי – מטלית מיקרופיבר לחה עם סבון עדין, והכל מושלם.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.55, delay: 0.1 }}
              className="relative"
            >
              <div className="relative rounded-3xl overflow-hidden border border-luxury-gold/20 aspect-[4/5] bg-gradient-to-br from-[#050505] via-[#111] to-luxury-charcoal shadow-[0_0_100px_rgba(212,175,55,0.12)]">
                <img
                  src="https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=925%20sterling%20silver%20jewelry%20underwater%20with%20E-Coating%20protection%20water%20droplets%20luxury%20product%20shot%20dramatic%20moody%20dark%20background%20gold%20rim%20light&image_size=portrait_4_3"
                  alt="E-Coating הגנה על תכשיטים"
                  className="w-full h-full object-cover product-image-glow opacity-95"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-luxury-black via-transparent to-transparent pointer-events-none" />

                <div className="absolute top-5 right-5 left-5 grid grid-cols-3 gap-2">
                  {[
                    { n: '5×', l: 'עמידות מוגברת' },
                    { n: '100%', l: 'עמיד למים' },
                    { n: '1 שנה', l: 'אחריות מלא' },
                  ].map((b) => (
                    <div key={b.l} className="rounded-xl glass-dark p-2.5 text-center">
                      <div className="text-sm sm:text-base font-black text-gold-gradient">{b.n}</div>
                      <div className="text-[10px] sm:text-xs text-luxury-text/80">{b.l}</div>
                    </div>
                  ))}
                </div>

                <div className="absolute bottom-5 right-5 left-5 rounded-2xl glass-dark p-4">
                  <p className="text-sm sm:text-base font-bold text-luxury-gold-light mb-1">
                    תוכנן לענידה יומיומית מלא. ללא פשרות.
                  </p>
                  <p className="text-xs sm:text-sm text-luxury-text/80">
                    מקלחות, ים, זיעה, אימונים, סבוני רחצה – הכל כשיר. הברק נשאר אמין.
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
}
