import { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X,
  ShoppingBag,
  Minus,
  Plus,
  Trash2,
  Truck,
  ShieldCheck,
  ArrowLeftRight,
  Gift,
  Sparkles,
  CreditCard,
  Lock,
} from 'lucide-react';
import { useCart } from '../context/CartContext.jsx';
import { getProductPricing, getVariantLabel } from '../data/products.js';

export default function CartDrawer() {
  const { state, totals, toggleCart, updateQuantity, removeItem, clearCart } = useCart();
  const { isOpen, items, freeShippingThreshold } = state;

  useEffect(() => {
    document.body.style.overflow = isOpen ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[60] cursor-pointer"
            onClick={() => toggleCart(false)}
          />
          <motion.aside
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'tween', duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
            className="fixed top-0 left-0 bottom-0 z-[70] w-full max-w-md bg-luxury-black border-l border-luxury-gold/20 shadow-2xl flex flex-col"
          >
            <div className="flex items-center justify-between p-5 border-b border-luxury-gold/15 bg-luxury-charcoal/40">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-gold-gradient text-luxury-black flex items-center justify-center shadow-gold-glow">
                  <ShoppingBag size={20} strokeWidth={2.2} />
                </div>
                <div>
                  <h3 className="font-black text-luxury-white text-lg leading-tight">
                    הסל שלך
                  </h3>
                  <p className="text-xs text-luxury-muted">
                    {totals.itemCount === 0
                      ? 'הסל עדיין ריק'
                      : `${totals.itemCount} פריטים בסל`}
                  </p>
                </div>
              </div>
              <button
                onClick={() => toggleCart(false)}
                className="w-9 h-9 rounded-full hover:bg-luxury-gold/10 flex items-center justify-center text-luxury-text hover:text-luxury-gold-light transition"
                aria-label="סגור סל"
              >
                <X size={20} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 scrollbar-hide">
              {items.length === 0 ? (
                <EmptyCart onClose={() => toggleCart(false)} />
              ) : (
                <>
                  <div className="rounded-2xl p-4 bg-luxury-gold/5 border border-luxury-gold/15">
                    <div className="flex items-center justify-between text-xs font-bold mb-2.5">
                      <span className="flex items-center gap-1.5 text-luxury-gold-light">
                        <Truck size={14} /> משלוח חינם
                      </span>
                      {totals.freeShippingUnlocked ? (
                        <span className="text-emerald-400">🎉 מאובטח!</span>
                      ) : (
                        <span className="text-luxury-muted">
                          נשאר עוד ₪{totals.remaining}
                        </span>
                      )}
                    </div>
                    <div className="h-2.5 rounded-full bg-luxury-black border border-luxury-gold/10 overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${totals.progress}%` }}
                        transition={{ duration: 0.6 }}
                        className="h-full bg-gold-gradient rounded-full"
                      />
                    </div>
                  </div>

                  {items.map((item) => {
                    const pricing = getProductPricing(item.product, item.variants, item.quantity);
                    return (
                      <CartItemRow
                        key={item.key}
                        item={item}
                        pricing={pricing}
                        onQty={(q) => updateQuantity(item.key, q)}
                        onRemove={() => removeItem(item.key)}
                      />
                    );
                  })}

                  <div className="rounded-2xl border border-luxury-gold/15 bg-luxury-charcoal/40 p-4 space-y-3">
                    <h4 className="font-bold text-sm text-luxury-gold-light flex items-center gap-1.5 mb-1">
                      <ShieldCheck size={15} /> האתר בטוח. ההזמנה מוגנת לחלוטין.
                    </h4>
                    <ul className="space-y-2.5">
                      {[
                        { icon: ShieldCheck, t: 'אחריות מלאה לשנה על הציפוי והאבנים' },
                        { icon: ArrowLeftRight, t: '14 ימי ניסיון – החזרה/החלפה ללא סיכון' },
                        { icon: Gift, t: 'משלוח מהיר באריזת מתנה יוקרתית' },
                      ].map(({ icon: I, t }) => (
                        <li key={t} className="flex items-start gap-2 text-sm text-luxury-text/85">
                          <I size={16} className="mt-0.5 text-luxury-gold-light shrink-0" />
                          <span>{t}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </>
              )}
            </div>

            {items.length > 0 && (
              <div className="border-t border-luxury-gold/15 bg-luxury-charcoal/60 p-4 sm:p-5">
                <div className="space-y-2 mb-4">
                  <div className="flex items-center justify-between text-sm text-luxury-text/80">
                    <span>סך הכל לפני הנחה</span>
                    <span className="line-through">₪{totals.original}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm text-emerald-400 font-bold">
                    <span className="flex items-center gap-1">
                      <Sparkles size={14} /> חיסכון מחיר השקה
                    </span>
                    <span>-₪{totals.original - totals.subtotal}</span>
                  </div>
                  <div className="flex items-center justify-between pt-2 mt-2 border-t border-luxury-gold/10">
                    <span className="font-bold text-luxury-white">סך לתשלום</span>
                    <div className="text-left">
                      <span className="text-2xl sm:text-3xl font-black text-gold-gradient">
                        ₪{totals.subtotal}
                      </span>
                      {totals.freeShippingUnlocked ? (
                        <div className="text-[11px] text-emerald-400 font-bold mt-0.5">
                          🎉 כולל משלוח חינם
                        </div>
                      ) : (
                        <div className="text-[11px] text-luxury-muted mt-0.5">
                          + משלוח (חינם מעל ₪{freeShippingThreshold})
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <button className="w-full py-4 rounded-xl bg-gold-gradient text-luxury-black font-black text-base hover:shadow-gold-glow-lg transition flex items-center justify-center gap-2 animate-pulse-gold">
                  <CreditCard size={20} strokeWidth={2.2} />
                  <span>לתשלום מאובטח – ₪{totals.subtotal}</span>
                  <Lock size={16} strokeWidth={2.2} />
                </button>
                <button
                  onClick={clearCart}
                  className="w-full mt-2.5 py-2.5 rounded-xl text-xs font-bold text-luxury-muted hover:text-red-400 hover:bg-red-500/5 transition flex items-center justify-center gap-1.5"
                >
                  <Trash2 size={14} /> רוקן את הסל
                </button>
              </div>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}

function CartItemRow({ item, pricing, onQty, onRemove }) {
  return (
    <div className="rounded-2xl border border-luxury-gold/15 bg-luxury-charcoal/40 overflow-hidden p-3.5 flex gap-3.5">
      <div className="w-24 h-24 sm:w-28 sm:h-28 shrink-0 rounded-xl overflow-hidden bg-gradient-to-br from-[#050505] to-[#1A1A1A] flex items-center justify-center">
        <img
          src={item.product.primaryImage}
          alt={item.product.title}
          className="w-[82%] h-[82%] object-contain silver-image-glow"
        />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2 mb-1.5">
          <h4 className="font-bold text-sm text-luxury-white leading-snug line-clamp-2">
            {item.product.title}
          </h4>
          <button
            onClick={onRemove}
            className="w-8 h-8 rounded-full hover:bg-red-500/10 text-luxury-muted hover:text-red-400 flex items-center justify-center shrink-0 transition"
            aria-label="הסר פריט"
          >
            <Trash2 size={15} />
          </button>
        </div>
        <p className="text-[11px] text-luxury-muted leading-snug line-clamp-1 mb-2">
          {getVariantLabel(item.product, item.variants)}
        </p>
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 border border-luxury-gold/25 rounded-full bg-luxury-black/60 p-0.5">
            <button
              onClick={() => onQty(item.quantity - 1)}
              className="w-8 h-8 rounded-full flex items-center justify-center text-luxury-text hover:text-luxury-gold-light hover:bg-luxury-gold/10 transition"
            >
              <Minus size={14} />
            </button>
            <span className="w-6 text-center text-sm font-bold text-luxury-white">
              {item.quantity}
            </span>
            <button
              onClick={() => onQty(item.quantity + 1)}
              className="w-8 h-8 rounded-full flex items-center justify-center text-luxury-text hover:text-luxury-gold-light hover:bg-luxury-gold/10 transition"
            >
              <Plus size={14} />
            </button>
          </div>
          <div className="text-left">
            <div className="text-xs text-luxury-muted line-through">₪{pricing.original}</div>
            <div className="text-lg font-black text-gold-gradient leading-tight">
              ₪{pricing.price}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function EmptyCart({ onClose }) {
  return (
    <div className="py-14 text-center">
      <div className="w-24 h-24 rounded-full bg-luxury-gold/8 border border-luxury-gold/25 flex items-center justify-center mx-auto mb-5">
        <ShoppingBag size={40} strokeWidth={1.6} className="text-luxury-gold-light" />
      </div>
      <h4 className="text-xl font-black text-luxury-white mb-2">הסל שלך עדיין ריק</h4>
      <p className="text-luxury-text/70 mb-7 max-w-xs mx-auto">
        הגיע הזמן להתפנק בתכשיט שישאר איתך לשנים. בחרתי את האוסף שלנו 💎
      </p>
      <a
        href="#shop"
        onClick={onClose}
        className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-gold-gradient text-luxury-black font-bold hover:shadow-gold-glow transition"
      >
        <Sparkles size={18} />
        <span>לעיון באוסף BÉLLACHY</span>
      </a>
    </div>
  );
}
