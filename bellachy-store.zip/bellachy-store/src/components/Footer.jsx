import { useState } from 'react';
import { motion } from 'framer-motion';
import { Diamond, Instagram, Mail, ShieldCheck, ArrowLeft, Heart } from 'lucide-react';

const columns = [
  {
    title: 'חנות',
    links: [
      { label: 'שרשרת מגן דוד', href: '#shop' },
      { label: 'עגילי מואסניט Signature', href: '#shop' },
      { label: 'אוסף מלא', href: '#shop' },
    ],
  },
  {
    title: 'מידע',
    links: [
      { label: 'מואסניט מול יהלום', href: '#compare' },
      { label: 'איכות E-Coating ועמידות', href: '#quality' },
      { label: 'שאלות נפוצות', href: '#faq' },
    ],
  },
  {
    title: 'שירות לקוחות',
    links: [
      { label: 'מדיניות משלוחים', href: '#faq' },
      { label: '14 ימי החזרה ללא סיכון', href: '#faq' },
      { label: 'אחריות שנה שלמה', href: '#faq' },
      { label: 'צור קשר', href: 'mailto:hello@bellachy.co.il' },
    ],
  },
];

export default function Footer() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const onSubscribe = (e) => {
    e.preventDefault();
    if (!email || !email.includes('@')) return;
    setSubscribed(true);
    setTimeout(() => {
      setSubscribed(false);
      setEmail('');
    }, 3200);
  };

  return (
    <footer className="relative mt-0 bg-luxury-black border-t border-luxury-gold/15 pt-16 pb-6 overflow-hidden">
      <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[800px] h-[300px] bg-luxury-gold/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-5 gap-10 pb-12 border-b border-luxury-gold/10">
          <div className="md:col-span-2">
            <div className="flex items-center mb-4">
              <Diamond className="text-luxury-gold-light ml-2" size={26} strokeWidth={1.6} />
              <span className="text-3xl font-black tracking-[0.22em] text-gold-gradient">
                BÉLLACHY
              </span>
            </div>
            <p className="text-luxury-text/70 mb-5 leading-relaxed max-w-md">
              אומנות על-זמנית. ברק ללא פשרות. תכשיטי כסף 925 ומואסניט GRA יוקרתיים
              שתוכננו לעמיד בבחינת הזמן – עם אחריות ושביעות רצון מלאות.
            </p>

            <form onSubmit={onSubscribe} className="max-w-sm">
              <label className="block text-sm font-semibold text-luxury-gold-light mb-2.5">
                הצטרפי למועדון BÉLLACHY וקבלי 10% הנחה על ההזמנה הראשונה 🎁
              </label>
              <div className="flex items-stretch rounded-xl overflow-hidden border border-luxury-gold/25 focus-within:border-luxury-gold/60 transition bg-luxury-charcoal/60">
                <input
                  type="email"
                  placeholder="הכניסי את המייל שלך"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="flex-1 bg-transparent px-4 py-3 text-sm text-luxury-white placeholder:text-luxury-muted outline-none"
                />
                <button
                  type="submit"
                  className="px-5 bg-gold-gradient text-luxury-black font-bold text-sm hover:shadow-gold-glow transition flex items-center gap-1"
                >
                  <span>הצטרפי</span>
                  <ArrowLeft size={16} />
                </button>
              </div>
              {subscribed && (
                <motion.p
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-2 text-sm text-luxury-gold-light flex items-center gap-1"
                >
                  <ShieldCheck size={16} /> תודה על ההצטרפות! קוד ההנחה נשלח למייל.
                </motion.p>
              )}
            </form>

            <div className="mt-6 flex items-center gap-3">
              <a
                href="https://instagram.com/_Bellachy_Official"
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 px-4 py-2.5 rounded-full border border-luxury-gold/25 text-sm text-luxury-text/90 hover:text-luxury-gold-light hover:border-luxury-gold/60 transition"
              >
                <Instagram size={18} />
                <span>@_Bellachy_Official</span>
              </a>
              <a
                href="mailto:hello@bellachy.co.il"
                className="flex items-center gap-2 px-4 py-2.5 rounded-full border border-luxury-gold/25 text-sm text-luxury-text/90 hover:text-luxury-gold-light hover:border-luxury-gold/60 transition"
              >
                <Mail size={18} />
                <span>צור קשר</span>
              </a>
            </div>
          </div>

          {columns.map((col) => (
            <div key={col.title}>
              <h4 className="text-luxury-white font-bold mb-4 text-sm tracking-wide">
                {col.title}
              </h4>
              <ul className="space-y-2.5">
                {col.links.map((l) => (
                  <li key={l.label}>
                    <a
                      href={l.href}
                      className="text-sm text-luxury-text/70 hover:text-luxury-gold-light transition"
                    >
                      {l.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-luxury-muted">
          <p className="flex items-center gap-1.5">
            © {new Date().getFullYear()} BÉLLACHY – כל הזכויות שמורות. נבנה עם
            <Heart size={13} className="text-luxury-gold-light fill-luxury-gold-light/30" /> בישראל.
          </p>
          <div className="flex items-center gap-5">
            <a href="#faq" className="hover:text-luxury-gold-light transition">מדיניות פרטיות</a>
            <a href="#faq" className="hover:text-luxury-gold-light transition">תנאי שימוש</a>
            <a href="#faq" className="hover:text-luxury-gold-light transition">מדיניות החזרה</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
