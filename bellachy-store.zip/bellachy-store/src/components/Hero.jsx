import { motion } from 'framer-motion';
import { ArrowDown, Sparkles, Shield, Star, CheckCircle2 } from 'lucide-react';
import { products } from '../data/products.js';

export default function Hero() {
  const heroProduct = products[0];
  return (
    <section id="top" className="relative overflow-hidden bg-dark-radial pt-10 sm:pt-16 pb-20 sm:pb-28">
      <div className="absolute inset-0 pointer-events-none opacity-60">
        <div className="absolute top-10 left-10 w-72 h-72 bg-luxury-gold/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-luxury-gold/5 rounded-full blur-[140px]" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-10 lg:gap-14 items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="order-2 lg:order-1"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-luxury-gold/30 bg-luxury-gold/5 backdrop-blur mb-6">
              <Sparkles size={16} className="text-luxury-gold-light" />
              <span className="text-xs sm:text-sm font-medium text-luxury-gold-light tracking-wide">
                ✦ מהדורת השקה | מחירי טרום-השקה לזמן מוגבל
              </span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black leading-[1.08] tracking-tight mb-5">
              <span className="text-luxury-white">אומנות על-זמנית.</span>
              <br />
              <span className="text-gold-gradient">ברק ללא פשרות.</span>
            </h1>

            <p className="text-base sm:text-lg text-luxury-text/80 leading-relaxed mb-7 max-w-xl">
              תכשיטי <strong className="text-luxury-white">כסף 925 מובחר</strong> ו
              <strong className="text-luxury-white">מואסניט GRA</strong> בדרגת איכות עליונה,
              עם ציפוי E-Coating המגן על הברק לאורך שנים – ללא חשש משחירה, חמצון או שחיקה.
            </p>

            <ul className="space-y-3 mb-8">
              {[
                'כסף אמיתי 925 + ציפוי רודיום / זהב 14K',
                'מואסניט VVS1 D-Color עם תעודת GRA מקורית',
                'עמיד למים וזיעה בשימוש יומיומי מלא',
                'אחריות שנה שלמה + 14 ימי ניסיון ללא סיכון',
              ].map((t) => (
                <li key={t} className="flex items-start gap-3 text-luxury-text/90">
                  <CheckCircle2 size={20} className="mt-0.5 text-luxury-gold-light shrink-0" />
                  <span>{t}</span>
                </li>
              ))}
            </ul>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <a
                href="#shop"
                className="group inline-flex items-center justify-center gap-2 px-7 py-4 rounded-xl bg-gold-gradient text-luxury-black font-extrabold text-base hover:shadow-gold-glow-lg transition-all animate-pulse-gold"
              >
                <Star size={20} className="fill-luxury-black/40" />
                <span>לרכישה במחיר השקה</span>
              </a>
              <a
                href="#reviews"
                className="inline-flex items-center justify-center gap-2 px-7 py-4 rounded-xl border border-luxury-gold/40 text-luxury-white font-semibold hover:bg-luxury-gold/10 transition"
              >
                <Shield size={19} />
                <span>ביקורות לקוחות (1,247)</span>
              </a>
            </div>

            <div className="mt-8 flex items-center gap-6 text-sm">
              <div className="flex items-center -space-x-2 space-x-reverse">
                {['#D4AF37', '#888', '#fff', '#E5C158'].map((c, i) => (
                  <div
                    key={i}
                    className="w-8 h-8 rounded-full border-2 border-luxury-charcoal flex items-center justify-center text-xs font-bold text-luxury-black"
                    style={{ background: c }}
                  >
                    {['נ', 'ד', 'ר', 'מ'][i]}
                  </div>
                ))}
              </div>
              <div className="text-luxury-text/80">
                <div className="flex items-center gap-1 text-luxury-gold-light">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} size={16} className="fill-current" />
                  ))}
                  <span className="font-bold mr-1 text-luxury-white">4.9/5</span>
                </div>
                <p className="text-xs text-luxury-muted">למעלה מ-1,200 לקוחות מרוצים</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="order-1 lg:order-2 relative"
          >
            <div className="relative mx-auto max-w-[460px] aspect-square rounded-[2rem] bg-gradient-to-br from-luxury-gold/20 via-luxury-charcoal to-transparent border border-luxury-gold/25 p-5 sm:p-8 shadow-[0_0_80px_rgba(212,175,55,0.15)]">
              <div className="absolute inset-0 rounded-[2rem] animate-shimmer pointer-events-none" />
              <div className="relative w-full h-full rounded-2xl overflow-hidden bg-gradient-to-br from-[#050505] to-[#1A1A1A] flex items-center justify-center">
                <img
                  src={heroProduct.gallery[0]}
                  alt={heroProduct.title}
                  className="w-[82%] h-[82%] object-contain silver-image-glow"
                  loading="eager"
                />
              </div>

              <motion.div
                animate={{ y: [0, -8, 0] }}
                transition={{ duration: 3.2, repeat: Infinity, ease: 'easeInOut' }}
                className="absolute -top-4 sm:-top-3 left-4 sm:left-8 px-4 py-2 rounded-xl glass-dark text-xs font-bold text-luxury-gold-light shadow-gold-glow"
              >
                ⚡ מהדורת השקה מוגבלת
              </motion.div>

              <motion.div
                animate={{ y: [0, 8, 0] }}
                transition={{ duration: 3.8, repeat: Infinity, ease: 'easeInOut', delay: 0.4 }}
                className="absolute -bottom-3 sm:-bottom-5 right-4 sm:right-8 px-4 py-2.5 rounded-xl glass-dark shadow-gold-glow"
              >
                <div className="text-[11px] text-luxury-muted line-through">₪{heroProduct.originalPrice}</div>
                <div className="text-lg font-black text-luxury-gold-light">₪{heroProduct.launchPrice}</div>
              </motion.div>

              <div className="absolute top-1/2 -translate-y-1/2 -left-3 sm:-left-6 px-3 py-2.5 rounded-xl glass-dark text-center max-w-[120px]">
                <div className="text-[10px] text-luxury-muted">E-Coating</div>
                <div className="text-[11px] font-bold text-luxury-white">עמיד למים</div>
              </div>
              <div className="absolute top-1/2 -translate-y-1/2 -right-3 sm:-right-6 px-3 py-2.5 rounded-xl glass-dark text-center max-w-[120px]">
                <div className="text-[10px] text-luxury-muted">תעודת</div>
                <div className="text-[11px] font-bold text-luxury-white">GRA מוסמכת</div>
              </div>
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.1 }}
          className="mt-16 flex justify-center"
        >
          <a href="#badges" className="text-luxury-muted hover:text-luxury-gold-light transition">
            <ArrowDown size={28} className="animate-bounce" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
