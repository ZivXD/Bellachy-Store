import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, HelpCircle, MessageCircleQuestion } from 'lucide-react';
import { faqs } from '../data/faqs.js';

export default function FAQSection() {
  const [open, setOpen] = useState(1);

  return (
    <section id="faq" className="relative py-20 sm:py-24 overflow-hidden">
      <div className="absolute top-0 left-1/3 w-[450px] h-[300px] bg-luxury-gold/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          className="text-center mb-12 sm:mb-14"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-luxury-gold/8 border border-luxury-gold/25 text-xs font-bold text-luxury-gold-light tracking-wider mb-5">
            <MessageCircleQuestion size={14} /> הסרו ספקות לפני הרכישה
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black mb-4 leading-tight">
            <span className="text-luxury-white">השאלות </span>
            <span className="text-gold-gradient">הנפוצות ביותר</span>
          </h2>
          <p className="text-luxury-text/75 text-base sm:text-lg">
            עליהן אנו נשאלים מדי יום. אם לא מצאתם כאן את התשובה – נשמח לעזור במייל או באינסטגרם.
          </p>
        </motion.div>

        <div className="space-y-3.5">
          {faqs.map((f, i) => {
            const active = open === f.id;
            return (
              <motion.div
                key={f.id}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.1 }}
                transition={{ duration: 0.4, delay: i * 0.06 }}
                className={`rounded-2xl border overflow-hidden transition-all ${
                  active
                    ? 'bg-luxury-charcoal/60 border-luxury-gold/40 shadow-[0_10px_40px_-10px_rgba(212,175,55,0.25)]'
                    : 'bg-luxury-charcoal/30 border-luxury-gold/15 hover:border-luxury-gold/30'
                }`}
              >
                <button
                  onClick={() => setOpen(active ? 0 : f.id)}
                  className="w-full flex items-center gap-4 p-5 sm:p-6 text-right"
                  aria-expanded={active}
                >
                  <div
                    className={`w-10 h-10 rounded-xl shrink-0 flex items-center justify-center transition ${
                      active
                        ? 'bg-gold-gradient text-luxury-black'
                        : 'bg-luxury-gold/10 border border-luxury-gold/20 text-luxury-gold-light'
                    }`}
                  >
                    {active ? <ChevronDown size={20} className="rotate-180 transition-transform" /> : <HelpCircle size={20} />}
                  </div>
                  <h3 className="flex-1 font-bold text-luxury-white text-sm sm:text-base leading-snug">
                    {f.question}
                  </h3>
                  <ChevronDown
                    size={20}
                    className={`text-luxury-gold-light shrink-0 transition-transform ${
                      active ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                <AnimatePresence initial={false}>
                  {active && (
                    <motion.div
                      key={f.id}
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: 'easeInOut' }}
                      className="overflow-hidden"
                    >
                      <div className="px-5 sm:px-6 pb-5 sm:pb-6 pr-16 sm:pr-20 -mt-2">
                        <div className="h-px w-full bg-luxury-gold/10 mb-4" />
                        <p className="text-luxury-text/85 leading-relaxed text-sm sm:text-base">
                          {f.answer}
                        </p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
          className="mt-10 sm:mt-12 rounded-2xl p-6 sm:p-8 bg-gradient-to-br from-luxury-gold/12 via-luxury-charcoal/60 to-transparent border border-luxury-gold/25 text-center"
        >
          <h3 className="font-black text-xl sm:text-2xl text-luxury-white mb-2">
            עדיין לא מצאת את התשובה? 💬
          </h3>
          <p className="text-luxury-text/80 mb-5">
            מדגימות – אנחנו כאן עבורך. שירות לקוחות עונה בתוך מספר שעות לכל הודעה.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <a
              href="https://instagram.com/_Bellachy_Official"
              target="_blank"
              rel="noreferrer"
              className="px-6 py-3 rounded-xl bg-gold-gradient text-luxury-black font-bold hover:shadow-gold-glow transition"
            >
              ✦ שלחי הודעה באינסטגרם
            </a>
            <a
              href="mailto:hello@bellachy.co.il"
              className="px-6 py-3 rounded-xl border border-luxury-gold/35 text-luxury-gold-light font-bold hover:bg-luxury-gold/10 transition"
            >
              ✉️hello@bellachy.co.il
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
