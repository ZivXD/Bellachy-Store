import { motion } from 'framer-motion';
import { Sparkles } from 'lucide-react';
import { products } from '../data/products.js';
import ProductCard from './ProductCard.jsx';

export default function FeaturedProducts() {
  return (
    <section id="shop" className="relative py-20 sm:py-28 overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 right-1/3 w-[500px] h-[300px] bg-luxury-gold/5 blur-[120px] rounded-full" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          className="text-center max-w-2xl mx-auto mb-14 sm:mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-luxury-gold/8 border border-luxury-gold/25 text-xs font-bold text-luxury-gold-light tracking-wider mb-5">
            <Sparkles size={14} /> אוסף BÉLLACHY • מהדורת השקה
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black mb-4 leading-tight">
            <span className="text-luxury-white">תכשיטים </span>
            <span className="text-gold-gradient">שנועדו להשאר</span>
          </h2>
          <p className="text-luxury-text/75 text-base sm:text-lg leading-relaxed">
            כל פריט באוסף נבדק באופן ידני לפני היציאה למשלוח, ומגיע באריזה יוקרתית
            עם תעודת איכות אישית ואחריות שנה שלמה.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-7 lg:gap-10 max-w-6xl mx-auto">
          {products.map((p, i) => (
            <ProductCard key={p.id} product={p} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
