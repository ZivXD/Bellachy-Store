import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingCart, Flame, Sparkles, Zap } from 'lucide-react';
import { useCart } from '../context/CartContext.jsx';
import { products, getProductPricing, getVariantLabel } from '../data/products.js';

export default function StickyBottomBar() {
  const { state, totals, addItem, toggleCart } = useCart();
  const { showStickyBar } = state;

  const [selectedProductId, setSelectedProductId] = useState(products[0].id);
  const product = products.find((p) => p.id === selectedProductId) || products[0];
  const [variants, setVariants] = useState({ ...product.defaultVariants });

  useEffect(() => {
    setVariants({ ...product.defaultVariants });
  }, [selectedProductId]);

  const pricing = getProductPricing(product, variants, 1);
  const variantLabel = getVariantLabel(product, variants);

  const onAdd = () => {
    addItem(product, variants, 1);
  };

  return (
    <AnimatePresence initial={false}>
      {showStickyBar && (
        <>
          <div className="h-24 md:hidden" aria-hidden />
          <motion.div
            initial={{ y: 120, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 120, opacity: 0 }}
            transition={{ type: 'spring', damping: 22, stiffness: 260 }}
            className="md:hidden fixed bottom-0 inset-x-0 z-50 pb-safe"
          >
            <div className="glass-dark border-t border-luxury-gold/25 shadow-[0_-10px_40px_rgba(0,0,0,0.5)] px-3 pt-3 pb-[calc(env(safe-area-inset-bottom)+12px)]">
              <div className="flex items-center gap-2 mb-2.5 overflow-x-auto scrollbar-hide">
                {products.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setSelectedProductId(p.id)}
                    className={`shrink-0 px-3 py-1.5 rounded-full text-[11px] font-bold border transition-all flex items-center gap-1 ${
                      selectedProductId === p.id
                        ? 'bg-luxury-gold/15 border-luxury-gold text-luxury-gold-light'
                        : 'bg-luxury-black/40 border-luxury-gold/15 text-luxury-text/80'
                    }`}
                  >
                    {p.id === 'star-of-david-necklace' ? (
                      <><Sparkles size={12} /> מגן דוד</>
                    ) : (
                      <><Zap size={12} /> מואסניט</>
                    )}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-3">
                <div className="w-14 h-14 shrink-0 rounded-xl overflow-hidden bg-gradient-to-br from-[#050505] to-[#1A1A1A] flex items-center justify-center border border-luxury-gold/15">
                  <img
                    src={product.primaryImage}
                    alt={product.title}
                    className="w-[80%] h-[80%] object-contain silver-image-glow"
                  />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline gap-1.5 mb-0.5">
                    <span className="text-[11px] text-luxury-muted line-through">
                      ₪{pricing.unitOriginal}
                    </span>
                    <span className="text-xl font-black text-gold-gradient leading-none">
                      ₪{pricing.unitPrice}
                    </span>
                    <Flame size={12} className="text-red-400" />
                  </div>
                  <div className="text-[10px] text-luxury-muted leading-tight line-clamp-1">
                    {variantLabel}
                  </div>
                  <div className="text-[10px] font-bold text-luxury-gold-light mt-0.5 flex items-center gap-1">
                    ⚡ נותרו {product.stockLeft} יחידות!
                  </div>
                </div>

                {totals.itemCount > 0 && (
                  <button
                    onClick={() => toggleCart(true)}
                    className="relative w-11 h-11 shrink-0 rounded-xl border border-luxury-gold/30 text-luxury-gold-light flex items-center justify-center hover:bg-luxury-gold/10 transition"
                    aria-label="פתח סל"
                  >
                    <ShoppingCart size={20} strokeWidth={2} />
                    <span className="absolute -top-1.5 -left-1.5 min-w-[18px] h-[18px] rounded-full bg-gold-gradient text-luxury-black text-[10px] font-black flex items-center justify-center px-1 shadow-gold-glow">
                      {totals.itemCount}
                    </span>
                  </button>
                )}

                <button
                  onClick={onAdd}
                  className="shrink-0 px-4 sm:px-5 py-3 rounded-xl bg-gold-gradient text-luxury-black font-black text-sm hover:shadow-gold-glow transition-all animate-pulse-gold flex items-center gap-1.5"
                >
                  <ShoppingCart size={17} strokeWidth={2.2} />
                  <span>הוסף</span>
                </button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
