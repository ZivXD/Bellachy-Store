import { Truck, Gem, Sparkles, Gift } from 'lucide-react';

const messages = [
  { icon: <Truck size={16} className="inline mx-1 text-luxury-gold-light" />, text: 'משלוח חינם בהזמנות מעל ₪299' },
  { icon: <Gem size={16} className="inline mx-1 text-luxury-gold-light" />, text: 'מהדורת השקה מוגבלת במחירי טרום-השקה' },
  { icon: <Sparkles size={16} className="inline mx-1 text-luxury-gold-light" />, text: 'תעודת GRA מקורית לכל עגילי מואסניט' },
  { icon: <Gift size={16} className="inline mx-1 text-luxury-gold-light" />, text: 'אריזת מתנה יוקרתית לכל הזמנה' },
];

export default function AnnouncementBar() {
  const content = [...messages, ...messages];
  return (
    <div className="bg-luxury-charcoal border-b border-luxury-gold/15 overflow-hidden relative">
      <div className="absolute inset-y-0 left-0 w-16 z-10 bg-gradient-to-l from-transparent to-luxury-charcoal pointer-events-none" />
      <div className="absolute inset-y-0 right-0 w-16 z-10 bg-gradient-to-r from-transparent to-luxury-charcoal pointer-events-none" />
      <div className="flex whitespace-nowrap animate-marquee py-2.5">
        {content.map((m, i) => (
          <span
            key={i}
            className="mx-10 inline-flex items-center text-sm font-medium text-luxury-text/90"
          >
            ✦ {m.icon} {m.text}
          </span>
        ))}
      </div>
    </div>
  );
}
