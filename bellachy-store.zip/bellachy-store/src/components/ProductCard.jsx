import { useState } from 'react';
import { motion } from 'framer-motion';
import { Minus, Plus, ShoppingCart, Check, Flame, Sparkles, CheckCircle2, ShieldCheck, ArrowLeft } from 'lucide-react';
import { getProductPricing, getVariantLabel } from '../data/products.js';
import { useCart } from '../context/CartContext.jsx';

export default function ProductCard({ product, index = 0 }) {
  const { addItem } = useCart();
  const [variants, setVariants] = useState({ ...product.defaultVariants });
  const [galleryIdx, setGalleryIdx] = useState(0);
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);

  const pricing = getProductPricing(product, variants, qty);

  const handleAdd = () => {
    addItem(product, variants, qty);
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  };

  const changeQty = (d) => setQty((q) => Math.max(1, Math.min(10, q + d)));

  return (
    <motion.article
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.15 }}
      transition={{ duration: 0.55, delay: index * 0.1 }}
      id={product.slug}
      className="group relative rounded-3xl bg-gradient-to-b from-luxury-charcoal/90 to-luxury-black border border-luxury-gold/18 overflow-hidden hover:border-luxury-gold/45 transition-all duration-500 hover:shadow-[0_30px_80px_-20px_rgba(212,175,55,0.25)]"
    >
      <div className="absolute top-4 right-4 z-20 flex flex-col gap-2">
        <div className="px-3 py-1.5 rounded-full bg-gradient-to-l from-red-600 to-red-500 text-luxury-white text-xs font-black shadow-lg flex items-center gap-1">
          <Flame size={13} />
          <span>חיסכון ₪{pricing.unitOriginal - pricing.unitPrice}</span>
        </div>
        <div className="px-3 py-1.5 rounded-full bg-luxury-charcoal/90 backdrop-blur border border-luxury-gold/25 text-xs font-bold text-luxury-gold-light flex items-center gap-1">
          <Sparkles size={12} />
          <span>נותרו {product.stockLeft} בלבד</span>
        </div>
      </div>

      <div className="relative aspect-square overflow-hidden bg-gradient-to-br from-[#050505] to-[#1A1A1A]">
        <div className="absolute inset-0 animate-shimmer pointer-events-none opacity-60" />
        <img
          src={product.gallery[galleryIdx]}
          alt={product.title}
          className="w-full h-full object-contain p-6 sm:p-10 silver-image-glow transition-transform duration-500 group-hover:scale-[1.04]"
        />

        {product.gallery.length > 1 && (
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-2 bg-luxury-black/60 backdrop-blur px-2.5 py-2 rounded-full border border-luxury-gold/15">
            {product.gallery.map((_, i) => (
              <button
                key={i}
                onClick={() => setGalleryIdx(i)}
                aria-label={`תמונה ${i + 1}`}
                className={`transition-all rounded-full ${
                  galleryIdx === i
                    ? 'w-6 h-2 bg-luxury-gold-light'
                    : 'w-2 h-2 bg-luxury-muted/60 hover:bg-luxury-muted'
                }`}
              />
            ))}
          </div>
        )}
      </div>

      <div className="p-5 sm:p-6 space-y-5">
        <div>
          <div className="flex items-center gap-1.5 text-luxury-gold-light mb-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <svg key={i} viewBox="0 0 24 24" className="w-3.5 h-3.5 fill-current">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
              </svg>
            ))}
            <span className="text-[11px] font-bold mr-1">4.9 • (1,247 ביקורות)</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-luxury-white leading-tight mb-2">
            {product.title}
          </h3>
          <p className="text-sm text-luxury-text/75 leading-relaxed">{product.shortDescription}</p>
        </div>

        <ul className="space-y-2">
          {product.features.map((f) => (
            <li key={f} className="flex items-start gap-2 text-sm text-luxury-text/85">
              <CheckCircle2 size={17} className="mt-0.5 text-luxury-gold-light shrink-0" />
              <span>{f}</span>
            </li>
          ))}
        </ul>

        <div className="divider-gold" />

        {product.variantGroups.map((group) => (
          <div key={group.key}>
            <div className="flex items-center justify-between mb-2.5">
              <label className="text-xs font-bold text-luxury-muted tracking-wider uppercase">
                {group.label}
              </label>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {group.options.map((opt) => {
                const active = variants[group.key] === opt.id;
                return (
                  <button
                    key={opt.id}
                    onClick={() =>
                      setVariants((v) => ({ ...v, [group.key]: opt.id }))
                    }
                    className={`relative text-right px-3.5 py-3 rounded-xl text-sm transition-all border ${
                      active
                        ? 'bg-luxury-gold/12 border-luxury-gold text-luxury-gold-light shadow-[inset_0_0_0_1px_rgba(212,175,55,0.3)]'
                        : 'bg-luxury-black/50 border-luxury-gold/15 text-luxury-text/85 hover:border-luxury-gold/35'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-semibold leading-snug">{opt.label}</span>
                      {opt.priceDelta !== undefined && opt.priceDelta !== 0 && (
                        <span className={`text-xs font-bold shrink-0 ${opt.priceDelta > 0 ? 'text-emerald-400' : 'text-luxury-gold-light'}`}>
                          {opt.priceDelta > 0 ? `+₪${opt.priceDelta}` : `-₪${Math.abs(opt.priceDelta)}`}
                        </span>
                      )}
                      {active && <Check size={16} className="text-luxury-gold-light shrink-0" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        ))}

        <div className="rounded-2xl bg-gradient-to-br from-luxury-gold/10 to-luxury-charcoal/70 border border-luxury-gold/20 p-4 sm:p-5">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-luxury-muted text-sm line-through">₪{pricing.unitOriginal}</span>
                <span className="px-2 py-0.5 rounded-md bg-red-500/15 border border-red-500/25 text-red-400 text-[10px] font-black">
                  {product.savingsBadge.split('–')[0].trim()}
                </span>
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-3xl sm:text-4xl font-black text-gold-gradient">
                  ₪{pricing.unitPrice}
                </span>
                {qty > 1 && (
                  <span className="text-xs text-luxury-muted">× {qty} = ₪{pricing.price}</span>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2 border border-luxury-gold/25 rounded-full bg-luxury-black/60 p-1">
              <button
                onClick={() => changeQty(-1)}
                className="w-9 h-9 rounded-full flex items-center justify-center text-luxury-text hover:text-luxury-gold-light hover:bg-luxury-gold/10 transition"
                aria-label="הפחת כמות"
              >
                <Minus size={16} />
              </button>
              <span className="w-7 text-center font-bold text-luxury-white">{qty}</span>
              <button
                onClick={() => changeQty(+1)}
                className="w-9 h-9 rounded-full flex items-center justify-center text-luxury-text hover:text-luxury-gold-light hover:bg-luxury-gold/10 transition"
                aria-label="הגדל כמות"
              >
                <Plus size={16} />
              </button>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 mb-4 text-xs text-luxury-text/80">
            <span className="inline-flex items-center gap-1">
              <ShieldCheck size={14} className="text-luxury-gold-light" /> אחריות שנה
            </span>
            <span className="inline-flex items-center gap-1">
              <ArrowLeft size={14} className="text-luxury-gold-light" /> 14 ימי החזרה
            </span>
            <span className="inline-flex items-center gap-1">💎 {getVariantLabel(product, variants)}</span>
          </div>

          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={handleAdd}
            className={`w-full py-4 rounded-xl font-extrabold text-base flex items-center justify-center gap-2 transition-all ${
              added
                ? 'bg-emerald-500 text-white shadow-lg'
                : 'bg-gold-gradient text-luxury-black hover:shadow-gold-glow-lg'
            }`}
          >
            {added ? (
              <>
                <Check size={20} /> <span>נוסף לסל בהצלחה ✨</span>
              </>
            ) : (
              <>
                <ShoppingCart size={20} strokeWidth={2.1} />
                <span>הוסף לסל – ₪{pricing.price}</span>
              </>
            )}
          </motion.button>
        </div>
      </div>
    </motion.article>
  );
}
