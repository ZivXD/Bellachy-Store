import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingBag, Menu, X, Diamond } from 'lucide-react';
import { useCart } from '../context/CartContext.jsx';

const navItems = [
  { label: 'חנות', href: '#shop' },
  { label: 'מואסניט מול יהלום', href: '#compare' },
  { label: 'איכות ועמידות', href: '#quality' },
  { label: 'ביקורות', href: '#reviews' },
  { label: 'שאלות נפוצות', href: '#faq' },
];

export default function Header() {
  const { totals, toggleCart } = useCart();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-40 w-full transition-all duration-300 ${
        scrolled
          ? 'glass-dark shadow-[0_8px_30px_rgba(0,0,0,0.35)]'
          : 'bg-luxury-black/70 backdrop-blur-md border-b border-luxury-gold/10'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          <button
            className="md:hidden p-2 -mr-2 text-luxury-text hover:text-luxury-gold transition"
            onClick={() => setMenuOpen(true)}
            aria-label="פתח תפריט"
          >
            <Menu size={24} />
          </button>

          <nav className="hidden md:flex items-center gap-8">
            {navItems.map((n) => (
              <a
                key={n.href}
                href={n.href}
                className="text-sm font-medium text-luxury-text/85 hover:text-luxury-gold-light transition-colors relative group"
              >
                {n.label}
                <span className="absolute -bottom-1 right-0 w-0 h-px bg-luxury-gold group-hover:w-full transition-all duration-300" />
              </a>
            ))}
          </nav>

          <a href="#top" className="flex items-center justify-center select-none">
            <Diamond className="text-luxury-gold-light ml-2" size={22} strokeWidth={1.6} />
            <span className="text-2xl sm:text-3xl font-black tracking-[0.22em] text-gold-gradient">
              BÉLLACHY
            </span>
          </a>

          <button
            className="relative p-2 -ml-2 text-luxury-text hover:text-luxury-gold transition"
            onClick={() => toggleCart(true)}
            aria-label="סל קניות"
          >
            <ShoppingBag size={24} strokeWidth={1.8} />
            {totals.itemCount > 0 && (
              <motion.span
                key={totals.itemCount}
                initial={{ scale: 0.4, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="absolute -top-0.5 -left-0.5 min-w-[20px] h-5 rounded-full bg-gold-gradient text-luxury-black text-xs font-bold flex items-center justify-center px-1 shadow-gold-glow"
              >
                {totals.itemCount}
              </motion.span>
            )}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {menuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 md:hidden"
              onClick={() => setMenuOpen(false)}
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'tween', duration: 0.3 }}
              className="fixed top-0 left-0 bottom-0 w-[80%] max-w-sm bg-luxury-charcoal border-l border-luxury-gold/20 z-50 md:hidden"
            >
              <div className="flex items-center justify-between p-5 border-b border-luxury-gold/15">
                <span className="text-xl font-black tracking-[0.2em] text-gold-gradient">BÉLLACHY</span>
                <button
                  className="p-2 text-luxury-text hover:text-luxury-gold"
                  onClick={() => setMenuOpen(false)}
                >
                  <X size={22} />
                </button>
              </div>
              <nav className="p-5 flex flex-col gap-1">
                {navItems.map((n) => (
                  <a
                    key={n.href}
                    href={n.href}
                    onClick={() => setMenuOpen(false)}
                    className="px-4 py-3 rounded-lg text-luxury-text/90 hover:text-luxury-gold-light hover:bg-white/5 transition"
                  >
                    {n.label}
                  </a>
                ))}
                <div className="divider-gold my-4" />
                <button
                  onClick={() => {
                    setMenuOpen(false);
                    toggleCart(true);
                  }}
                  className="mt-2 w-full px-4 py-3 rounded-lg bg-gold-gradient text-luxury-black font-bold hover:shadow-gold-glow transition"
                >
                  🛍️ מעבר לסל קניות ({totals.itemCount})
                </button>
              </nav>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </header>
  );
}
