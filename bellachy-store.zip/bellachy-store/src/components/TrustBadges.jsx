import { motion } from 'framer-motion';
import { Gem, Droplets, Shield, Truck } from 'lucide-react';

const badges = [
  {
    icon: Gem,
    title: 'מואסניט GRA',
    subtitle: 'VVS1 • D-Color • תעודה מקורית',
    color: 'from-luxury-gold-light to-amber-200',
  },
  {
    icon: Droplets,
    title: 'E-Coating עמיד למים',
    subtitle: 'ללא שחיקה • ללא השחרה',
    color: 'from-cyan-300 to-sky-400',
  },
  {
    icon: Shield,
    title: 'כסף 925 + זהב 14K',
    subtitle: 'חומרי גלם באיכות יוקרתית',
    color: 'from-slate-200 to-zinc-300',
  },
  {
    icon: Truck,
    title: 'משלוח מהיר & מתנה',
    subtitle: 'חינם מעל ₪299 • אריזה יוקרתית',
    color: 'from-emerald-300 to-teal-400',
  },
];

export default function TrustBadges() {
  return (
    <section id="badges" className="relative py-14 sm:py-16 border-y border-luxury-gold/10 bg-luxury-black/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
          {badges.map((b, i) => {
            const Icon = b.icon;
            return (
              <motion.div
                key={b.title}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{ duration: 0.45, delay: i * 0.08 }}
                className="group relative p-5 sm:p-6 rounded-2xl border border-luxury-gold/15 bg-luxury-charcoal/40 hover:border-luxury-gold/40 hover:bg-luxury-charcoal/70 transition-all"
              >
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 bg-gradient-to-br ${b.color} bg-opacity-15 relative`}
                >
                  <div className="absolute inset-0 rounded-xl bg-luxury-charcoal opacity-70" />
                  <Icon className="relative text-luxury-gold-light" size={24} strokeWidth={1.8} />
                </div>
                <h3 className="font-bold text-luxury-white text-sm sm:text-base mb-1.5">
                  {b.title}
                </h3>
                <p className="text-xs sm:text-sm text-luxury-text/70 leading-relaxed">
                  {b.subtitle}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
