import { createContext, useContext, useMemo, useReducer, useCallback } from 'react';
import { getProductPricing } from '../data/products.js';

const CartContext = createContext(null);

const initialState = {
  items: [],
  isOpen: false,
  freeShippingThreshold: 299,
  showStickyBar: false,
};

function cartReducer(state, action) {
  switch (action.type) {
    case 'ADD_ITEM': {
      const { product, variants, quantity = 1 } = action.payload;
      const key = `${product.id}::${JSON.stringify(variants)}`;
      const existingIdx = state.items.findIndex((i) => i.key === key);
      let items;
      if (existingIdx >= 0) {
        items = state.items.map((i, idx) =>
          idx === existingIdx ? { ...i, quantity: i.quantity + quantity } : i,
        );
      } else {
        items = [
          ...state.items,
          {
            key,
            productId: product.id,
            product,
            variants,
            quantity,
            addedAt: Date.now(),
          },
        ];
      }
      return { ...state, items };
    }
    case 'UPDATE_QUANTITY': {
      const { key, quantity } = action.payload;
      const q = Math.max(1, Math.min(99, Number(quantity) || 1));
      return {
        ...state,
        items: state.items.map((i) => (i.key === key ? { ...i, quantity: q } : i)),
      };
    }
    case 'REMOVE_ITEM': {
      return {
        ...state,
        items: state.items.filter((i) => i.key !== action.payload.key),
      };
    }
    case 'CLEAR_CART': {
      return { ...state, items: [] };
    }
    case 'TOGGLE_CART': {
      return { ...state, isOpen: action.payload ?? !state.isOpen };
    }
    case 'SET_STICKY_BAR': {
      return { ...state, showStickyBar: !!action.payload };
    }
    default:
      return state;
  }
}

export function CartProvider({ children }) {
  const [state, dispatch] = useReducer(cartReducer, initialState);

  const addItem = useCallback((product, variants, quantity = 1) => {
    dispatch({ type: 'ADD_ITEM', payload: { product, variants, quantity } });
    dispatch({ type: 'TOGGLE_CART', payload: true });
  }, []);

  const updateQuantity = useCallback((key, quantity) => {
    dispatch({ type: 'UPDATE_QUANTITY', payload: { key, quantity } });
  }, []);

  const removeItem = useCallback((key) => {
    dispatch({ type: 'REMOVE_ITEM', payload: { key } });
  }, []);

  const clearCart = useCallback(() => dispatch({ type: 'CLEAR_CART' }), []);

  const toggleCart = useCallback(
    (val) => dispatch({ type: 'TOGGLE_CART', payload: val }),
    [],
  );

  const setShowStickyBar = useCallback(
    (val) => dispatch({ type: 'SET_STICKY_BAR', payload: val }),
    [],
  );

  const totals = useMemo(() => {
    let subtotal = 0;
    let original = 0;
    let itemCount = 0;
    state.items.forEach((item) => {
      const pr = getProductPricing(item.product, item.variants, item.quantity);
      subtotal += pr.price;
      original += pr.original;
      itemCount += item.quantity;
    });
    const progress = Math.min(100, Math.round((subtotal / state.freeShippingThreshold) * 100));
    const remaining = Math.max(0, state.freeShippingThreshold - subtotal);
    const freeShippingUnlocked = subtotal >= state.freeShippingThreshold;
    return { subtotal, original, itemCount, progress, remaining, freeShippingUnlocked };
  }, [state.items, state.freeShippingThreshold]);

  const value = useMemo(
    () => ({
      state,
      totals,
      addItem,
      updateQuantity,
      removeItem,
      clearCart,
      toggleCart,
      setShowStickyBar,
    }),
    [state, totals, addItem, updateQuantity, removeItem, clearCart, toggleCart, setShowStickyBar],
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}
