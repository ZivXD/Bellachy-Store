const STAR_IMG_1 = "https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=luxury%20925%20sterling%20silver%20Star%20of%20David%20pendant%20necklace%20with%20diamonds%20on%20dark%20matte%20black%20background%20dramatic%20lighting%20high%20end%20jewelry%20photography&image_size=square_hd";
const STAR_IMG_2 = "https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=elegant%20Star%20of%20David%20silver%20pendant%20with%20spiga%20chain%20macro%20jewelry%20shot%20dark%20background%20luxury%20product%20photography&image_size=square_hd";
const STAR_IMG_3 = "https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=woman%20wearing%20delicate%20silver%20Star%20of%20David%20necklace%20pendant%20soft%20skin%20tones%20close%20up%20aesthetic%20fashion%20photo&image_size=square_hd";
const STAR_IMG_4 = "https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=womans%20neckline%20wearing%20dainty%20925%20silver%20Star%20of%20David%20pendant%20on%20chain%20warm%20soft%20light%20lifestyle%20jewelry%20photography&image_size=square_hd";
const STAR_IMG_5 = "https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=925%20silver%20Star%20of%20David%20pendant%20lying%20on%20textured%20natural%20stone%20rock%20dramatic%20jewelry%20flat%20lay%20dark%20moody%20lighting&image_size=square_hd";

const EARRING_IMG_1 = "https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=pair%20of%20brilliant%20round%20moissanite%20stud%20earrings%20925%20sterling%20silver%20setting%20sparkle%20fire%20dark%20matte%20background%20luxury%20jewelry%20macro&image_size=square_hd";
const EARRING_IMG_2 = "https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=close%20up%20VVS1%20D%20color%20moissanite%20diamond%20stud%20earrings%20in%2014k%20gold%20plated%20925%20silver%20luxury%20product%20photography%20dark%20background&image_size=square_hd";
const EARRING_IMG_3 = "https://coresg-normal.trae.ai/api/ide/v1/text_to_image?prompt=woman%20wearing%20sparkling%20moissanite%20diamond%20stud%20earrings%20soft%20portrait%20elegant%20luxury%20lifestyle%20photography&image_size=square_hd";

export const products = [
  {
    id: 'star-of-david-necklace',
    title: 'שרשרת תליון מגן דוד הקלאסית',
    slug: 'star-of-david-necklace',
    category: 'שרשראות',
    originalPrice: 489,
    launchPrice: 349,
    savingsBadge: 'חיסכון של ₪140 – מחיר השקה',
    scarcityBadge: '⚡ מהדורת השקה מוגבלת – יחידות אחרונות במלאי',
    stockLeft: 7,
    shortDescription: 'שרשרת תליון מגן דוד בעיצוב מדויק ועוצמתי, עשויה כסף אמיתי 925 מובחר. מיועדת לעמידות מקסימלית ולענידה יומיומית ללא חשש מחלודה או שחיקה.',
    features: [
      'בסיס כסף אמיתי 925 (Solid 925 Sterling Silver)',
      'ציפוי הגנה מתקדם E-Coating (עמיד למים, זיעה ומונע השחרה/חמצון)',
      'גימור מבריק ברמת גימור יוקרתית עם שרשרת עמידה במיוחד',
    ],
    gallery: [STAR_IMG_1, STAR_IMG_2, STAR_IMG_3, STAR_IMG_4, STAR_IMG_5],
    primaryImage: STAR_IMG_1,
    variantGroups: [
      {
        key: 'plating',
        label: 'בחירת ציפוי',
        options: [
          { id: 'rhodium', label: 'כסף 925 ציפוי רודיום', priceDelta: 0 },
          { id: 'gold14k', label: 'ציפוי זהב צהוב 14K על כסף 925', priceDelta: 60 },
        ],
      },
      {
        key: 'chainLength',
        label: 'בחירת אורך שרשרת',
        options: [
          { id: '45', label: '45 ס"מ', priceDelta: 0 },
          { id: '50', label: '50 ס"מ', priceDelta: 0 },
          { id: '55', label: '55 ס"מ', priceDelta: 20 },
        ],
      },
    ],
    defaultVariants: { plating: 'rhodium', chainLength: '50' },
  },
  {
    id: 'moissanite-stud-earrings',
    title: 'עגילי מואסניט צמודים – Signature',
    slug: 'moissanite-stud-earrings',
    category: 'עגילים',
    originalPrice: 590,
    launchPrice: 399,
    savingsBadge: 'חיסכון של ₪191 – מחיר השקה',
    scarcityBadge: '🔥 מבוקש ביותר – מלאי ראשון מוגבל',
    stockLeft: 12,
    shortDescription: 'ניצוץ וברק יוצאי דופן הכוללים אבני מואסניט בדרגת איכות VVS1 D-Color עם תעודה מוסמכת (GRA), משובצות בכסף אמיתי 925 עם ציפוי E-Coating מגן.',
    features: [
      'אבני Moissanite מקוריות עם תעודת GRA (עוברות בדיקת יהלומים)',
      'דרגת ניקיון VVS1, דרגת צבע D-Color',
      'בסיס כסף אמיתי 925 עם ציפוי E-Coating יוקרתי',
      'סגירה מאובטחת ונוחה',
    ],
    gallery: [EARRING_IMG_1, EARRING_IMG_2, EARRING_IMG_3],
    primaryImage: EARRING_IMG_1,
    variantGroups: [
      {
        key: 'plating',
        label: 'בחירת ציפוי',
        options: [
          { id: 'rhodium', label: 'כסף 925 ציפוי רודיום', priceDelta: 0 },
          { id: 'gold14k', label: 'ציפוי זהב צהוב 14K על כסף 925', priceDelta: 80 },
        ],
      },
      {
        key: 'carat',
        label: 'בחירת גודל קראט',
        options: [
          { id: '0.5', label: '0.5 קראט לאוזן', priceDelta: 0, basePrice: 399, originalPrice: 590 },
          { id: '1.0', label: '1.0 קראט לאוזן', priceDelta: 180, basePrice: 579, originalPrice: 820 },
          { id: '2.0', label: '2.0 קראט לאוזן', priceDelta: 420, basePrice: 819, originalPrice: 1190 },
        ],
      },
    ],
    defaultVariants: { plating: 'rhodium', carat: '0.5' },
  },
];

export function getProductPricing(product, selectedVariants, quantity = 1) {
  let basePrice = product.launchPrice;
  let originalPrice = product.originalPrice;

  product.variantGroups.forEach((group) => {
    const selectedId = selectedVariants[group.key];
    const option = group.options.find((o) => o.id === selectedId);
    if (option) {
      if (option.basePrice !== undefined) {
        basePrice = option.basePrice;
        originalPrice = option.originalPrice || originalPrice;
      } else {
        basePrice += option.priceDelta || 0;
        originalPrice += option.priceDelta || 0;
      }
    }
  });

  return {
    price: basePrice * quantity,
    original: originalPrice * quantity,
    unitPrice: basePrice,
    unitOriginal: originalPrice,
  };
}

export function getVariantLabel(product, selectedVariants) {
  return product.variantGroups
    .map((group) => {
      const opt = group.options.find((o) => o.id === selectedVariants[group.key]);
      return opt ? opt.label : '';
    })
    .filter(Boolean)
    .join(' • ');
}
